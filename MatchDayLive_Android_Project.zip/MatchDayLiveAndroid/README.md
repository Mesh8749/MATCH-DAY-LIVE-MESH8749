# MatchDay Live HD — Android starter project

This is an Android Studio/Gradle WebView wrapper around the MatchDay Live prototype.

## Important current limitations
- This is a starter project, not a finished commercial streaming service.
- The fixture cards are illustrative placeholders, not verified live fixtures.
- The WATCH LIVE buttons are disabled until the operator connects licensed stream URLs.
- No broadcaster streams, live score feed, accounts, shared chat backend, or admin dashboard are included.
- Do not distribute copyrighted sports broadcasts without the required rights and permissions.

## Build
Open this folder in Android Studio or use the included GitHub Actions workflow to build.
The workflow creates a debug APK and an unsigned release AAB. The AAB must be signed for Play Console upload. Configure Play App Signing in Play Console.

Application ID: `com.matchdaylive.football`
Minimum Android: 6.0 (API 23)
Target SDK: 35

## Before Play Store release
1. Replace placeholder fixtures with a licensed football data API and show accurate kickoff times/time zones.
2. Integrate a broadcaster/streaming provider with written rights for the intended territory.
3. Implement server-backed user accounts/chat if needed, plus reporting and moderation.
4. Publish a privacy policy and complete Play Console Data Safety, content rating, app access and target audience declarations accurately.
5. Add production app icon, screenshots, store description and signed release bundle.
6. Test on real devices and meet current Google Play policy requirements.
